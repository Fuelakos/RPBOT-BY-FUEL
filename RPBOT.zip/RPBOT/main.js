const Discord = require('discord.js');
const client = new Discord.Client
const prefix = '!'
const config = require('./config.json');



client.commands = new Discord.Collection();


client.once('ready', () => {
  console.log('Fuel bot has came online!');
});





////////////////////////////////TWITTER///////////////////////////////


client.on("message", message =>{
  if (message.author.bot) return;
  if (message.channel.id === config.TWT){
  if(!message.attachments.first()){  
          message.delete();
          const exampleEmbed = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#277ecd')
          .setDescription("" + message.content + "")
          .setImage()
          .setFooter('Twitter', 'https://cdn.discordapp.com/attachments/800068913164714035/810141920747716628/twitter-logo-2-1.png')
          message.channel.send(exampleEmbed);
  

  }
}
  if (message.author.bot) return;
  if (message.channel.id === config.TWT){
  if(!message.content){  
          message.delete();
          const exampleEmbed2 = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#277ecd')
          .setImage(message.attachments.first().proxyURL)
          .setFooter('Twitter', 'https://cdn.discordapp.com/attachments/800068913164714035/810141920747716628/twitter-logo-2-1.png')
          message.channel.send(exampleEmbed2);
  

  }
}
  else if (message.author.bot) return;
  if (message.channel.id === config.TWT){
  if (message.content, message.attachments.first()){ 
          message.delete();
          const exampleEmbed3 = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#277ecd')
          .setDescription("" + message.content + "")
          .setImage(message.attachments.first().proxyURL)
          .setFooter('Twitter', 'https://cdn.discordapp.com/attachments/800068913164714035/810141920747716628/twitter-logo-2-1.png')
          message.channel.send(exampleEmbed3);
  

  }
}
 if(message.channel.id === config.TWT){ //twt channelid
  let channel = message.guild.channels.cache.get(config.TWT_LOGS) //twt logs channelid
  if(!message.attachments.first()){ 
    let twtlogs = new Discord.MessageEmbed()
    .setTitle("TWT LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setColor("#277ecd")
    .setTimestamp()
    .setFooter("Twt made by Fuel#5292")
    channel.send(twtlogs);
  }

  if(!message.content){
      let channel2 = message.guild.channels.cache.get(config.TWT_LOGS) //twt logs channelid
      let twtlogs2 = new Discord.MessageEmbed()
      .setTitle("TWT LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `NULL`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setColor("#277ecd")
    .setFooter("Twt made by Fuel#5292")
     channel2.send(twtlogs2)
    } 
    
    
    else if(message.content, message.attachments.first()){
      let channel3 = message.guild.channels.cache.get(config.TWT_LOGS) //twt logs channelid
      let twtlogs3 = new Discord.MessageEmbed()
      .setTitle("DARKNET LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setColor("#277ecd")
    .setFooter("Twt made by Fuel#5292")
    channel3.send(twtlogs3)
    }


  
  } 

})












//////////////////////////////////////////DARKCHAT//////////////////////////////////////




client.on('message', async message => {
  if(message.author.bot) return;

if(message.channel.id === config.DARKNET){ //dark chat channelid
  message.channel.send(message.content, message.attachments.first())
  message.delete({ timeout: 100 })
  }
  if(message.channel.id === config.DARKNET){ //dark chat channelid
    let darkchannel = message.guild.channels.cache.get(config.DARKNET_LOGS) //dark chat logs channelid
    if(!message.attachments.first()){ 
      let darkembed = new Discord.MessageEmbed()
      .setTitle("DARKNET LOGS")
      .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setTimestamp()
    .setFooter("Dark net logs made by Fuel#5292")
    darkchannel.send(darkembed)
    }
    
    if(!message.content){
      let darkchannel2 = message.guild.channels.cache.get(config.DARKNET_LOGS) //dark chat logs channelid
      let darkembed2 = new Discord.MessageEmbed()
      .setTitle("DARKNET LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `NULL`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setFooter("Dark net logs made by Fuel#5292")
    darkchannel2.send(darkembed2)
    }
    else if(message.content, message.attachments.first()){
      let darkchannel3 = message.guild.channels.cache.get(config.DARKNET_LOGS) //dark chat logs channelid
      let darkembed3 = new Discord.MessageEmbed()
      .setTitle("DARKNET LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setFooter("Dark net logs made by Fuel#5292")
    darkchannel3.send(darkembed3)
    }
  } 
     
});



///////////////////////////////////////////////INSTAGRAM//////////////////////////////////







client.on("message", message =>{
  if (message.author.bot) return;
  if (message.channel.id === config.INSTA){
  if(!message.attachments.first()){  
          message.delete();
          const InstagramexampleEmbed = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#fc0066')
          .setDescription("" + message.content + "")
          .setImage()
          .setFooter('Instagram', 'https://cdn.discordapp.com/attachments/790844941525319710/813125111367991296/283-2831746_insta-icon-instagram.png')
          message.channel.send(InstagramexampleEmbed);
  

  }
}
  if (message.author.bot) return;
  if (message.channel.id === config.INSTA){
  if(!message.content){  
          message.delete();
          const InstagramexampleEmbed2 = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#fc0066')
          .setImage(message.attachments.first().proxyURL)
          .setFooter('Instagram', 'https://cdn.discordapp.com/attachments/790844941525319710/813125111367991296/283-2831746_insta-icon-instagram.png')
          message.channel.send(InstagramexampleEmbed2);
  

  }
}
  else if (message.author.bot) return;
  if (message.channel.id === config.INSTA){
  if (message.content, message.attachments.first()){ 
          message.delete();
          const InstagramexampleEmbed3 = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#fc0066s')
          .setDescription("" + message.content + "")
          .setImage(message.attachments.first().proxyURL)
          .setFooter('Instagram', 'https://cdn.discordapp.com/attachments/790844941525319710/813125111367991296/283-2831746_insta-icon-instagram.png')
          message.channel.send(InstagramexampleEmbed3);
  

  }
}
 if(message.channel.id === config.INSTA){ //Instagram channelid
  let Instagramchannel = message.guild.channels.cache.get(config.INSTA_LOGS) //Instagram logs channelid
  if(!message.attachments.first()){ 
    let Instagramlogs = new Discord.MessageEmbed()
    .setTitle("INSTAGRAM LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setColor("#fc0066")
    .setTimestamp()
    .setFooter("Instagram made by Fuel#5292")
    Instagramchannel.send(Instagramlogs);
  }

  if(!message.content){
      let Instagramchannel2 = message.guild.channels.cache.get(config.INSTA_LOGS) //Instagram logs channelid
      let Instagramlogs2 = new Discord.MessageEmbed()
      .setTitle("INSTAGRAM LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `NULL`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setColor("#fc0066")
    .setFooter("Instagram made by Fuel#5292")
    Instagramchannel2.send(Instagramlogs2)
    } 
    
    
    else if(message.content, message.attachments.first()){
      let Instagramchannel3 = message.guild.channels.cache.get(config.INSTA_LOGS) //Instagram logs channelid
      let Instagramlogs3 = new Discord.MessageEmbed()
      .setTitle("INSTAGRAM LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setColor("#fc0066")
    .setFooter("Instagram made by Fuel#5292")
    Instagramchannel3.send(Instagramlogs3)
    }


  
  } 

})








client.login(config.BOT_TOKEN);