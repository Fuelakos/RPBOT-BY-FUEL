const Discord = require('discord.js');
const {MessageEmbed} = require('discord.js')
const client = new Discord.Client({ partials: ["MESSAGE", "CHANNEL", "REACTION"]});
const prefix = '!'
const config = require('./config.json');



client.once('ready', () => {
  console.log('RPBOT MADE BY Fuel#5292 | ALL RIGHTS RESERVED | WAVE DESIGNS');
});




client.on('message', message =>{
  if(!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();





/////////////DARKCHAT//////////////
client.on('message', async message => {
    if(message.author.bot) return;

if(message.channel.id === config.DARKNET){ //dark chat channelid
    message.channel.send(message.content, message.attachments.first())
    message.delete({ timeout: 100 })
    }
    if(message.channel.id === config.DARKNET){ //dark chat channelid
      let darkchannel = message.guild.channels.cache.get(config.DARKNET_LOGS) //dark chat logs channelid
      if(!message.attachments.first()){ 
        let darkembed = new Discord.MessageEmbed()
        .setTitle("DARKNET LOGS")
        .addField("Author:", `${message.author.tag}`)
      .addField("Message:", `${message.content}`)
      .setTimestamp()
      .setFooter("Dark net logs made by Fuel#5292")
      darkchannel.send(darkembed)
      }
      
      if(!message.content){
        let darkchannel2 = message.guild.channels.cache.get(config.DARKNET_LOGS) //dark chat logs channelid
        let darkembed2 = new Discord.MessageEmbed()
        .setTitle("DARKNET LOGS")
      .addField("Author:", `${message.author.tag}`)
      .addField("Message:", `NULL`)
      .setImage(message.attachments.first().proxyURL)
      .setTimestamp()
      .setFooter("Dark net logs made by Fuel#5292")
      darkchannel2.send(darkembed2)
      }
      else if(message.content, message.attachments.first()){
        let darkchannel3 = message.guild.channels.cache.get(config.DARKNET_LOGS) //dark chat logs channelid
        let darkembed3 = new Discord.MessageEmbed()
        .setTitle("DARKNET LOGS")
      .addField("Author:", `${message.author.tag}`)
      .addField("Message:", `${message.content}`)
      .setImage(message.attachments.first().proxyURL)
      .setTimestamp()
      .setFooter("Dark net logs made by Fuel#5292")
      darkchannel3.send(darkembed3)
      }
    } 
       
});









/////////////////TWITTER+LOGS/////////////////// 
  
  
  
  
  
  
  
  
  
  
client.on("message", message =>{
    if (message.author.bot) return;
    if (message.channel.id === config.TWT){
    if(!message.attachments.first()){  
            message.delete();
            const exampleEmbed = new Discord.MessageEmbed()
            .setAuthor(message.author.username, message.author.avatarURL())
            .setColor('#277ecd')
            .setDescription("" + message.content + "")
            .setImage()
            .setFooter('Twitter', 'https://cdn.discordapp.com/attachments/800068913164714035/810141920747716628/twitter-logo-2-1.png')
            message.channel.send(exampleEmbed);
    
  
    }
  }
    if (message.author.bot) return;
    if (message.channel.id === config.TWT){
    if(!message.content){  
            message.delete();
            const exampleEmbed2 = new Discord.MessageEmbed()
            .setAuthor(message.author.username, message.author.avatarURL())
            .setColor('#277ecd')
            .setImage(message.attachments.first().proxyURL)
            .setFooter('Twitter', 'https://cdn.discordapp.com/attachments/800068913164714035/810141920747716628/twitter-logo-2-1.png')
            message.channel.send(exampleEmbed2);
    
  
    }
  }
    else if (message.author.bot) return;
    if (message.channel.id === config.TWT){
    if (message.content, message.attachments.first()){ 
            message.delete();
            const exampleEmbed3 = new Discord.MessageEmbed()
            .setAuthor(message.author.username, message.author.avatarURL())
            .setColor('#277ecd')
            .setDescription("" + message.content + "")
            .setImage(message.attachments.first().proxyURL)
            .setFooter('Twitter', 'https://cdn.discordapp.com/attachments/800068913164714035/810141920747716628/twitter-logo-2-1.png')
            message.channel.send(exampleEmbed3);
    
  
    }
  }
   if(message.channel.id === config.TWT){ //twt channelid
    let channel = message.guild.channels.cache.get(config.TWT_LOGS) //twt logs channelid
    if(!message.attachments.first()){ 
      let twtlogs = new Discord.MessageEmbed()
      .setTitle("TWT LOGS")
      .addField("Author:", `${message.author.tag}`)
      .addField("Message:", `${message.content}`)
      .setColor("#277ecd")
      .setTimestamp()
      .setFooter("Twt made by Fuel#5292")
      channel.send(twtlogs);
    }
  
    if(!message.content){
        let channel2 = message.guild.channels.cache.get(config.TWT_LOGS) //twt logs channelid
        let twtlogs2 = new Discord.MessageEmbed()
        .setTitle("TWT LOGS")
      .addField("Author:", `${message.author.tag}`)
      .addField("Message:", `NULL`)
      .setImage(message.attachments.first().proxyURL)
      .setTimestamp()
      .setColor("#277ecd")
      .setFooter("Twt made by Fuel#5292")
       channel2.send(twtlogs2)
      } 
      
      
      else if(message.content, message.attachments.first()){
        let channel3 = message.guild.channels.cache.get(config.TWT_LOGS) //twt logs channelid
        let twtlogs3 = new Discord.MessageEmbed()
        .setTitle("TWT LOGS")
      .addField("Author:", `${message.author.tag}`)
      .addField("Message:", `${message.content}`)
      .setImage(message.attachments.first().proxyURL)
      .setTimestamp()
      .setColor("#277ecd")
      .setFooter("Twt made by Fuel#5292")
      channel3.send(twtlogs3)
      }
  
  
    
    } 
  
  })








  /////////////////INSTAGRAM/////////////////// 
  
  
  
  
  
  
  
  
  
  
client.on("message", message =>{
  if (message.author.bot) return;
  if (message.channel.id === config.INSTA){
  if(!message.attachments.first()){  
          message.delete();
          const instagramEmbed = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#fc0059')
          .setDescription("" + message.content + "")
          .setImage()
          .setFooter('Instagram', 'https://cdn.discordapp.com/attachments/800068913164714035/812322014689755187/283-2831746_insta-icon-instagram.png')
          message.channel.send(instagramEmbed);
  

  }
}
  if (message.author.bot) return;
  if (message.channel.id === config.INSTA){
  if(!message.content){  
          message.delete();
          const instagramEmbed2 = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#fc0059')
          .setImage(message.attachments.first().proxyURL)
          .setFooter('Instagram', 'https://cdn.discordapp.com/attachments/800068913164714035/812322014689755187/283-2831746_insta-icon-instagram.png')
          message.channel.send(instagramEmbed2);
  

  }
}
  else if (message.author.bot) return;
  if (message.channel.id === config.INSTA){
  if (message.content, message.attachments.first()){ 
          message.delete();
          const instagramEmbed3 = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL())
          .setColor('#fc0059')
          .setDescription("" + message.content + "")
          .setImage(message.attachments.first().proxyURL)
          .setFooter('Instagram', 'https://cdn.discordapp.com/attachments/800068913164714035/812322014689755187/283-2831746_insta-icon-instagram.png')
          message.channel.send(instagramEmbed3);
  

  }
}
 if(message.channel.id === config.INSTA){ //twt channelid
  let channel = message.guild.channels.cache.get(config.INSTA_LOGS) //twt logs channelid
  if(!message.attachments.first()){ 
    let instagramlogs = new Discord.MessageEmbed()
    .setTitle("INSTAGRAM LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setColor("#fc0059")
    .setTimestamp()
    .setFooter("Instagram made by Fuel#5292")
    channel.send(instagramlogs);
  }

  if(!message.content){
      let channel2 = message.guild.channels.cache.get(config.INSTA_LOGS) //twt logs channelid
      let instagramlogs2 = new Discord.MessageEmbed()
      .setTitle("INSTAGRAM LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `NULL`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setColor("#fc0059")
    .setFooter("Instagram made by Fuel#5292")
     channel2.send(instagramlogs2)
    } 
    
    
    else if(message.content, message.attachments.first()){
      let channel3 = message.guild.channels.cache.get(config.INSTA_LOGS) //twt logs channelid
      let instagramlogs3 = new Discord.MessageEmbed()
      .setTitle("INSTAGRAM LOGS")
    .addField("Author:", `${message.author.tag}`)
    .addField("Message:", `${message.content}`)
    .setImage(message.attachments.first().proxyURL)
    .setTimestamp()
    .setColor("#fc0059")
    .setFooter("Instagram made by Fuel#5292")
    channel3.send(instagramlogs3)
    }


  
  } 

})






client.login(config.BOT_TOKEN);